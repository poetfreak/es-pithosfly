#!/bin/bash

echo ' install python3-setuptools python3-dbus python3-gi python3-gi-cairo   gir1.2-gstreamer-1.0 gir1.2-gst-plugins-base-1.0 gstreamer1.0-plugins-good gstreamer1.0-plugins-bad    python3-pylast gir1.2-appindicator3-* gir1.2-notify-0.7 gir1.2-keybinder-3.0 gnome-icon-theme-symbolic   python3-mutagen'
sudo apt-get install python3-setuptools python3-dbus python3-gi python3-gi-cairo   gir1.2-gstreamer-1.0 gir1.2-gst-plugins-base-1.0 gstreamer1.0-plugins-good gstreamer1.0-plugins-bad    python3-pylast gir1.2-appindicator3-* gir1.2-notify-0.7 gir1.2-keybinder-3.0 gnome-icon-theme-symbolic   python3-mutagen

sudo ./setup.py install

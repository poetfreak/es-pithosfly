# -*- coding: utf-8 -*-
from gi.repository import Gtk

class AboutDialog(Gtk.AboutDialog):
    def __init__(self, parent=None):
        super().__init__()
        self.set_program_name("ES-PithosFly")
        self.set_version("2.69.0")
        self.set_comments("Pandora.com client for the Linux desktop\n\nES-PithosFly is a lightweight, native Pandora Radio client.")
        self.set_website("https://github.com/poetfreak/es-pithosfly")
        self.set_authors(["Eric Sebasta <allpraise@gmail.com>", "Kevin Mehall <km@kevinmehall.net>"])
        self.set_logo_icon_name("pithos")

def NewAboutDialog(parent=None):
    return AboutDialog(parent)
